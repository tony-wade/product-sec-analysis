################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
A51_UPPER_SRCS += \
C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/SILABS_STARTUP.A51 

C_SRCS += \
../src/F380_UART_SIM_main.c \
../src/system_init.c \
../src/timer.c \
../src/uart_sim.c 

OBJS += \
./src/F380_UART_SIM_main.OBJ \
./src/SILABS_STARTUP.OBJ \
./src/system_init.OBJ \
./src/timer.OBJ \
./src/uart_sim.OBJ 


# Each subdirectory must supply rules for building sources it contributes
src/%.OBJ: ../src/%.c src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Keil 8051 Compiler'
	C51 "@$(patsubst %.OBJ,%.__i,$@)" || $(RC)
	@echo 'Finished building: $<'
	@echo ' '

src/F380_UART_SIM_main.OBJ: C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/C8051F380/inc/SI_C8051F380_Register_Enums.h C:/Users/User/Desktop/PRINTER_DATA/HP_turn_on_interior_exterior_sig/F380_UART_SIM/src/system_init.h C:/Users/User/Desktop/PRINTER_DATA/HP_turn_on_interior_exterior_sig/F380_UART_SIM/src/uart_sim.h C:/Users/User/Desktop/PRINTER_DATA/HP_turn_on_interior_exterior_sig/F380_UART_SIM/src/timer.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/toolchains/keil_8051/9.60/INC/STDIO.H C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/C8051F380/inc/SI_C8051F380_Defs.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/stdint.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/si_toolchain.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/stdbool.h

src/SILABS_STARTUP.OBJ: C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/SILABS_STARTUP.A51 src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Keil 8051 Assembler'
	AX51 "@$(patsubst %.OBJ,%.__ia,$@)" || $(RC)
	@echo 'Finished building: $<'
	@echo ' '

src/system_init.OBJ: C:/Users/User/Desktop/PRINTER_DATA/HP_turn_on_interior_exterior_sig/F380_UART_SIM/src/system_init.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/C8051F380/inc/SI_C8051F380_Register_Enums.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/C8051F380/inc/SI_C8051F380_Defs.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/si_toolchain.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/stdint.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/stdbool.h

src/timer.OBJ: C:/Users/User/Desktop/PRINTER_DATA/HP_turn_on_interior_exterior_sig/F380_UART_SIM/src/timer.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/C8051F380/inc/SI_C8051F380_Register_Enums.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/C8051F380/inc/SI_C8051F380_Defs.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/si_toolchain.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/stdint.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/stdbool.h

src/uart_sim.OBJ: C:/Users/User/Desktop/PRINTER_DATA/HP_turn_on_interior_exterior_sig/F380_UART_SIM/src/uart_sim.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/C8051F380/inc/SI_C8051F380_Register_Enums.h C:/Users/User/Desktop/PRINTER_DATA/HP_turn_on_interior_exterior_sig/F380_UART_SIM/src/system_init.h C:/Users/User/Desktop/PRINTER_DATA/HP_turn_on_interior_exterior_sig/F380_UART_SIM/src/timer.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/stdint.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/C8051F380/inc/SI_C8051F380_Defs.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/si_toolchain.h C:/SiliconLabs/SimplicityStudio/v5_3/developer/sdks/8051/v4.3.1/Device/shared/si8051Base/stdbool.h


