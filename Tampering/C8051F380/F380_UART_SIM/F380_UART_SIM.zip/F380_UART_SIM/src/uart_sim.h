#ifndef UART_SIM_H_
#define UART_SIM_H_

#include <stdint.h>   // extern


extern const uint8_t code RX_SpeedUpSeq[];
extern const uint8_t RX_SpeedUpSeq_Size;


void UART0_test_input(uint8_t *list, uint8_t len);
void UART1_test_input(uint8_t *list, uint8_t len);


void TestRoutine(void);



#endif /* UART_SIM_H_ */
