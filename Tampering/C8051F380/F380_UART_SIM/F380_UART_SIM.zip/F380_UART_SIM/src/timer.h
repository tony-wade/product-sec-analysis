#ifndef TIMER_H_
#define TIMER_H_




void Wait_us_Timer0(unsigned long us);



#endif /* TIMER_H_ */
