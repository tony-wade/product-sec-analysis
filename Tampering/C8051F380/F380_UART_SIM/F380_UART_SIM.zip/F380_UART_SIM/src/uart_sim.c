#include "uart_sim.h"

#include <SI_C8051F380_Register_Enums.h>
#include "system_init.h"
#include "timer.h"


//-----------------------------------------------------------------------------
// Variables
//-----------------------------------------------------------------------------
#define UART_BUFFERSIZE 256   // 2^N for faster operation



// put in outer ram
xdata uint8_t TX_Buffer[UART_BUFFERSIZE];   // KEY: 1 UART interrupt handle byte write, the other handle byte read
xdata uint8_t RX_Buffer[UART_BUFFERSIZE];


volatile uint8_t TX_head_idx = 0;       // update frequently, read value every time
volatile uint8_t TX_tail_idx = 0;
volatile uint8_t RX_head_idx = 0;
volatile uint8_t RX_tail_idx = 0;


// special seq set for speed up
const uint8_t code RX_SpeedUpSeq[] = {0x89, 0x42, 0x0, 0x2a, 0x0, 0x0, 0x14, 0xec, 0x8a};
const uint8_t RX_SpeedUpSeq_Size = sizeof(RX_SpeedUpSeq);



// overwrite sequences
const uint8_t xdata cond_A[] = {0x89, 0x82, 0xA0, 0x0, 0xA0, 0x0, 0x91, 0x5b, 0x8A}; // is ptr already
const uint8_t xdata cond_B[] = {0x89, 0x42, 0x0, 0x0, 0x73, 0xcd, 0x8a};

const uint8_t xdata target_A[] = {
    0x89, 0x2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,0x2,0x10,0x0,0x0,
    0x0,0x2,0x0,0x0,0x80,0x0,0x20,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
    0x0,0x0,0x60,0x80,0x50,0x0,0x40,0x0,0x0,0x0,0x42,0x42,0x0,
    0x0,0x0,0x0,0x80,0x0,0x64,0x0,0x4,0x0,0x60,0x02,0x40,0x0,
    0xf0,0x4f,0x8a
};

const uint8_t xdata target_B[] = {0x89,0x82,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x64,
    0x0,0x4,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80
    ,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80
    ,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,0x0,0x80,
    0x0,0x49,0xa6,0x8a
};


typedef enum {
  WAIT_SPEEDUP,
  WAIT_TRIGGER,
  OVERWRITE,
  DONE,
} CommuState;

static volatile CommuState State = WAIT_SPEEDUP;  // static = this file only



#define TRIGGER_COUNT 2

// xdata for sufficient speed
typedef struct{
    const uint8_t xdata *cond;
    uint8_t cond_size;

    const uint8_t xdata *target;
    uint8_t target_size;                // <255, ptr/size no need for const
} Trigger_t;


const Trigger_t trigger_table[] = {     // const for fix obj
    {
        cond_A,
        sizeof(cond_A),
        target_A,
        sizeof(target_A),
    },
    {
        cond_B,
        sizeof(cond_B),
        target_B,
        sizeof(target_B)
    }
};

Trigger_t *trig;            // cache current addr in Trigger_t
static volatile uint8_t rx_byte;       // current byte value, change in isr. note that char is -128~127, so don't use here
//static volatile uint8_t  tx_byte;
static volatile bool RX_ready = 1;               // prevent overwrite

static volatile uint8_t byte_idx = 0;   // next byte in sequence,<255
static volatile uint8_t seq_idx = 0;    // next sequence index



//-----------------------------------------------------------------------------
// F380, circular w/r process
//-----------------------------------------------------------------------------

void UART0_read(uint8_t *buffer, uint8_t *buffer_idx)
{
  buffer[*buffer_idx] = SBUF0;       // from Receive register, diff from send
  *buffer_idx = (*buffer_idx + 1) & (UART_BUFFERSIZE - 1);
}

void UART0_write(uint8_t *buffer, uint8_t *buffer_idx)
{
  SBUF0 = buffer[*buffer_idx];       // to Transmit register
  *buffer_idx = (*buffer_idx + 1) & (UART_BUFFERSIZE - 1);
}


// read into rx ring buffer & rx_byte
static void UART1_read_RX(void){
  rx_byte  = SBUF1;                     // read Rx value, from Receive register, diff from send
  RX_Buffer[RX_tail_idx] = rx_byte;
  RX_tail_idx = (RX_tail_idx + 1) & (UART_BUFFERSIZE - 1);
}

// prevent FIFO Overrun and block write
static void UART1_read_halt(void){
  RX_Buffer[RX_tail_idx] = SBUF1;
}

// write from  rx ring buffer
static void UART1_write_RX(void){
  SBUF1 = RX_Buffer[RX_head_idx];       // to Transmit register
  RX_head_idx = (RX_head_idx + 1) & (UART_BUFFERSIZE - 1);
}

// write from pre-def seq with extra index
static void UART1_overwrite(uint8_t xdata *buffer){
  //while(!RX_ready);
  RX_ready = 0;
  SBUF1 = buffer[byte_idx++];
}





//-----------------------------------------------------------------------------
// ISR for RX,  for better mcu, use double DMA with Half-Transfer Interrupt
//-----------------------------------------------------------------------------
SI_INTERRUPT(UART1_Interrupt, UART1_IRQn){
  // read 1 write 1 for bridging
  if (SCON1 & 0x01){
      SCON1 &= ~0x01;   // clr flag

      // write 1 send 1
      switch(State){

        case WAIT_SPEEDUP:
          UART1_read_RX();
          UART1_write_RX();

          if (rx_byte != RX_SpeedUpSeq[byte_idx]){
              byte_idx = 0;
          }else{

              byte_idx += 1;
          }
          if (byte_idx == RX_SpeedUpSeq_Size){
              change_baud_req = 1;      // set flag
              byte_idx = 0;
              State = WAIT_TRIGGER;
              trig = &trigger_table[seq_idx];   // load table

              //if (trig->cond_size == 9) LED = 1;    // easy check
          }
          break;


        case WAIT_TRIGGER:
          UART1_read_RX();
          UART1_write_RX();

          if (rx_byte != trig->cond[byte_idx]){   // same effect as below
              byte_idx = 0;
          }else{
              byte_idx += 1;

              if (byte_idx >= (*trig).cond_size){
                  //LED = 1;                 // for easy check
                  byte_idx = 0;             // reset
                  State = OVERWRITE;
              }
          }
          break;


        case OVERWRITE:   // if overwrite seq has different length with the old one would cause problem
          UART1_read_halt();
          UART1_overwrite(trig->target);

          if (byte_idx >= trig->target_size){   // END OF A SEQ
              byte_idx = 0;
              seq_idx += 1;

              if (seq_idx >= TRIGGER_COUNT){    // is last seq
                  LED = 1;
                  State = DONE;
              }else{
                  State = WAIT_TRIGGER;
                  trig = &trigger_table[seq_idx];   // load next table
              }
          }
          break;

        case DONE:
          // this isr is compact, thus next write interrupt collides with
          // prev write process(using same sfr) -> crash
          //UART1_read_RX();
          //UART1_write_RX();
          SBUF1 = SBUF1;        // 2 different buffer, so no problem
          break;
      }
  }

  if (SCON1 & 0x02) {
      SCON1 &= ~0x02;
      RX_ready = 1;
  }
}




//-----------------------------------------------------------------------------
// for Test only
//-----------------------------------------------------------------------------

// test data input , remember XBR0 has to assigned, else close
void UART0_test_input(uint8_t *list, uint8_t len){
  int i;

  for (i=0; i<len; i++){
      TX_Buffer[TX_tail_idx] = list[i];
      TX_tail_idx = (TX_tail_idx + 1) & (UART_BUFFERSIZE - 1);
  }
}

void UART1_test_input(uint8_t *list, uint8_t len){
  int i;

  for (i=0; i<len; i++){
      RX_Buffer[RX_tail_idx] = list[i];
      RX_tail_idx = (RX_tail_idx + 1) & (UART_BUFFERSIZE - 1);
  }
}



// test seq sending, uart0: officially recommend method: uart1: interrupt
void TestRoutine(void){
  while (TX_head_idx != TX_tail_idx){
      UART0_write(TX_Buffer, &TX_head_idx);
      SCON0_TI = 0;
      while (!SCON0_TI);
      LED = 0;
  }
  while (RX_head_idx != RX_tail_idx){
      RX_ready = 0;
      UART1_write_RX();
      while(!RX_ready);   // prevent overwrite
  }
}
