//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
#include <SI_C8051F380_Register_Enums.h>                // SFR declarations
#include "system_init.h"
#include "uart_sim.h"
#include "timer.h"
#include "stdio.h"




//-----------------------------------------------------------------------------
// SiLabs_Startup() Routine
// ----------------------------------------------------------------------------
// This function is called immediately after reset, before the initialization
// code is run in SILABS_STARTUP.A51 (which runs before main() ). This is a
// useful place to disable the watchdog timer, which is enable by default
// and may trigger before main() in some instances.
//-----------------------------------------------------------------------------
void SiLabs_Startup (void)
{
   PCA0MD &= ~0x40;                    // Disable Watchdog timer
}



void Init_Device(void){
  PORT_Init();
  SYSCLK_Init();
  //Timer0_Init();

  IE_EA = 1;
}

//-----------------------------------------------------------------------------
// main() Routine
// ----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
int main (void)
{
  Init_Device();

  //Wait_us_Timer0(8500000);    // for tx pin operation

  // if use Change_Baudrate(Wait_us_Timer0) than need to stop using/defining uart0
  // since CKCON is used in both function, and rest of the timers are all auto-reload type.
  //Timer0_Deact();
  PORT_UART_Init();
  //UART0_Init ();
  UART1_Init ();

  // SEND TEST, UART0  ok, UART1 bridge success ,parser?
  //UART0_test_input(RX_SpeedUpSeq, RX_SpeedUpSeq_Size);
  //UART1_test_input(RX_SpeedUpSeq, RX_SpeedUpSeq_Size);  // direct sending test
  //TestRoutine();



  while (1) {
      if (change_baud_req){
          Change_Baudrate(BAUDRATE1);
          change_baud_req = 0;      // prevent trigger twice
          Wait_us_Timer0(1000);
      }
  }
}
