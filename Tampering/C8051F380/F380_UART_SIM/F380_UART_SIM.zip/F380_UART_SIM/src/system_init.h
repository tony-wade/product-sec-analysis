#ifndef SYSTEM_INIT_H_
#define SYSTEM_INIT_H_

#include <SI_C8051F380_Register_Enums.h>

//-----------------------------------------------------------------------------
// Global Constants
//-----------------------------------------------------------------------------
#define SYSCLK          48000000       // variable for calculation

#define BAUDRATE0       9640
#define BAUDRATE1       227280


extern volatile bool change_baud_req;


//-----------------------------------------------------------------------------
// GPIO Setting
//-----------------------------------------------------------------------------
SI_SBIT(LED, SFR_P2, 2);                 // LED='1' means ON



//-----------------------------------------------------------------------------
// Function Declarations
//-----------------------------------------------------------------------------
void PORT_Init(void);
void PORT_UART_Init(void);
void SYSCLK_Init(void);
void Timer0_Init(void);
void Timer0_Deact(void);
void UART0_Init (void);
void UART1_Init (void);

void Change_Baudrate(unsigned long speed);


#endif /* SYSTEM_INIT_H_ */
