#include "system_init.h"




// run in main loop
volatile bool change_baud_req = 0;


// ----------------------------------------------------------------------------
// Port Initialization
// ----------------------------------------------------------------------------
void PORT_Init(void) {

  P0MDOUT |= 0x11;                   // set P0.0, P0.4 to push-pull output

  P2MDOUT |= 0x04;                   // set LED to push-pull
  XBR1 = 0x40;
  P0 = 0x10;                         // P0.4 high, 0.0 Low
  LED = 0;
}


//  set voltage high and enable UART to port after wait()
void PORT_UART_Init(void)
{
  P0 = 0x11;                          // set uart tx pins high
  XBR1 &= ~0x40;                      // disable crossbar

  //XBR0 = 0x01;                        // route UART 0 to crossbar, pin is defined by XBAR
  XBR2 = 0x01;                        // route UART 1 to crossbar, pin is defined by XBAR=0.0 0.1
  XBR1 = 0x40;                        // enable crossbar
}



//-----------------------------------------------------------------------------
// SYSCLK Initialization
//-----------------------------------------------------------------------------
void SYSCLK_Init(void) {
    int16_t x;
    OSCICN |= 0x03;                     // Internal oscillator = 12 MHz

    CLKMUL  = 0x00;                     // Select internal oscillator as
                                        // input to clock multiplier( 12*4 )

    CLKMUL |= 0x80;                     // Enable clock multiplier
    for(x = 0;x < 500; x++);            // Delay for clock multiplier to begin
    CLKMUL |= 0xC0;                     // Initialize the clock multiplier
    for(x = 0;x < 500; x++);

    while(!(CLKMUL & 0x20));            // Wait for multiplier to lock
    CLKSEL  = 0x03;                     // Select system clock
}




//-----------------------------------------------------------------------------
// Timer0_Init
//-----------------------------------------------------------------------------
void Timer0_Init(void)
{
   TMOD = 0x01;                         // Timer0 in 16-bit mode
   CKCON = 0x02;                         // Timer0 uses a 1:48 prescaler(1 MHz)
   IE_ET0 = 1;                          // Timer0 interrupt enabled
}

// reset CKCON for uart0
void Timer0_Deact(void){
  IE_ET0 = 0;                           // disable

  CKCON = 0x0;                          // reset for uart0
}






//-----------------------------------------------------------------------------
// UART0_Init, use CKCON that even affect timer0..., only use for sending
//-----------------------------------------------------------------------------
// Configure the UART0 using Timer1, for baudrate0 and 8-N-1(8 bits data, no parity bit, 1 stop bit).
//-----------------------------------------------------------------------------
void UART0_Init (void)
{
   SCON0 = 0x10;                       // SCON0: 8-bit variable bit rate
                                       //        level of STOP bit is ignored
                                       //        RX enabled
                                       //        ninth bits are zeros
                                       //        clear SCON0_RI and SCON0_TI bits

   // Timer1 baudrate formula
   if (SYSCLK/BAUDRATE0/2/256 < 1) {
      TH1 = -(SYSCLK/BAUDRATE0/2);
      CKCON &= ~0x0B;                  // T1M = 1; SCA1:0 = xx
      CKCON |=  0x08;
   } else if (SYSCLK/BAUDRATE0/2/256 < 4) {
      TH1 = -(SYSCLK/BAUDRATE0/2/4);
      CKCON &= ~0x0B;                  // T1M = 0; SCA1:0 = 01
      CKCON |=  0x09;
   } else if (SYSCLK/BAUDRATE0/2/256 < 12) {
      TH1 = -(SYSCLK/BAUDRATE0/2/12);
      CKCON &= ~0x0B;                  // T1M = 0; SCA1:0 = 00
   } else {
      TH1 = -(SYSCLK/BAUDRATE0/2/48);
      CKCON &= ~0x0B;                  // T1M = 0; SCA1:0 = 10
      CKCON |=  0x02;
   }

   TL1 = TH1;                          // init Timer1
   TMOD &= 0x0f;                       // TMOD: timer 1 in 8-bit auto reload
   TMOD |=  0x20;
   TCON_TR1 = 1;                       // START Timer1
   SCON0_TI = 1;                       // Indicate TX0 ready
}


//-----------------------------------------------------------------------------
// UART1_Init
//-----------------------------------------------------------------------------
// Configure UART1 and it's interrupt for baudrate0 and 8-N-1. (with baud rate generator)
//-----------------------------------------------------------------------------
void UART1_Init (void)
{
   SMOD1 = 0x0C;                       // set to disable parity, 8-data bit,
                                       // disable extra bit,
                                       // stop bit 1 bit wide

   SCON1 = 0x10;                       // SCON1: 8-bit variable bit rate
                                       //        level of STOP bit is ignored
                                       //        RX enabled
                                       //        ninth bits are zeros
                                       //        clear SCON0_RI and SCON0_TI bits

   // Baud Rate Generator formula
   if (SYSCLK/BAUDRATE0/2/0xFFFF < 1) {
      SBRL1 = -(SYSCLK/BAUDRATE0/2);   // = SBRL
      SBCON1 |= 0x03;                  // set prescaler to 1
   } else if (SYSCLK/BAUDRATE0/2/0xFFFF < 4) {
      SBRL1 = -(SYSCLK/BAUDRATE0/2/4);
      SBCON1 &= ~0x03;
      SBCON1 |= 0x01;                  // set prescaler to 4

   } else if (SYSCLK/BAUDRATE0/2/0xFFFF < 12) {
      SBRL1 = -(SYSCLK/BAUDRATE0/2/12);
      SBCON1 &= ~0x03;                 // set prescaler to 12
   } else {
      SBRL1 = -(SYSCLK/BAUDRATE0/2/48);
      SBCON1 &= ~0x03;
      SBCON1 |= 0x02;                  // set prescaler to 4
   }

   SBCON1 |= 0x40;                     // enable baud rate generator
   SCON1 |= 0x02;                      // TI = 1
   EIE2 |= 0x2;                        // Enable UART1 interrupts
}



//-----------------------------------------------------------------------------
// F380 only, change uart0, uart1's baud rates
//-----------------------------------------------------------------------------
void Change_Baudrate(unsigned long speed){    // "long" prevent int truncation(0xFFFF/0xFF)
  /*
  TCON_TR1 = 0;                       // stop Timer1(uart0)
  */

  EIE2 &= ~0x2;                       // stop uart1 interrupt
  SBCON1 &= ~0x40;                    // stop baud rate generator

  /*
  // uart 0
  if (SYSCLK/speed/2/256 < 1) {
     TH1 = -(SYSCLK/speed/2);
     CKCON &= ~0x0B;                  // T1M = 1; SCA1:0 = xx
     CKCON |=  0x08;
  } else if (SYSCLK/speed/2/256 < 4) {
     TH1 = -(SYSCLK/speed/2/4);
     CKCON &= ~0x0B;                  // T1M = 0; SCA1:0 = 01
     CKCON |=  0x09;
  } else if (SYSCLK/speed/2/256 < 12) {
     TH1 = -(SYSCLK/speed/2/12);
     CKCON &= ~0x0B;                  // T1M = 0; SCA1:0 = 00
  } else {
     TH1 = -(SYSCLK/speed/2/48);
     CKCON &= ~0x0B;                  // T1M = 0; SCA1:0 = 10
     CKCON |=  0x02;
  }

  TL1 = TH1;                          // init Timer1
  TCON_TR1 = 1;                       // START Timer1
  */

  // uart 1
  if (SYSCLK/speed/2/0xFFFF < 1) {
     SBRL1 = -(SYSCLK/speed/2);   // = SBRL
     SBCON1 |= 0x03;                  // set prescaler to 1
  } else if (SYSCLK/speed/2/0xFFFF < 4) {
     SBRL1 = -(SYSCLK/speed/2/4);
     SBCON1 &= ~0x03;
     SBCON1 |= 0x01;                  // set prescaler to 4

  } else if (SYSCLK/speed/2/0xFFFF < 12) {
     SBRL1 = -(SYSCLK/speed/2/12);
     SBCON1 &= ~0x03;                 // set prescaler to 12
  } else {
     SBRL1 = -(SYSCLK/speed/2/48);
     SBCON1 &= ~0x03;
     SBCON1 |= 0x02;                  // set prescaler to 4
  }

  SBCON1 |= 0x40;                     // enable baud rate generator
  EIE2 |= 0x2;                        // Enable UART1 interrupts
}

















