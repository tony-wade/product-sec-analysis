#include "timer.h"

#include <SI_C8051F380_Register_Enums.h>


// timer1 is used by uart0! timer0/1's CKCON pre-scale is used
// res of the timer are all auto-reload type
static volatile bool timer0_done = true;






//-----------------------------------------------------------------------------
//  busy Wait() with microsecond resolution
//-----------------------------------------------------------------------------
static void _wait_Timer0(unsigned int us) {
    unsigned int value;

    timer0_done = false;    // reset

    value = 65536UL - us;  // 1MHz as timer clock, at most 65535
    TH0 = value >> 8;    // High byte
    TL0 = value & 0xFF;  // Low byte

    TCON_TR0 = 1;  // Start Timer0

    while(!timer0_done);  // Wait until ISR (done)
}



void Wait_us_Timer0(unsigned long us) {
    while (us >= 60000) {
        _wait_Timer0(60000);
        us -= 60000;
    }
    if (us > 0) {
        _wait_Timer0((unsigned int)us);
    }
}




//-----------------------------------------------------------------------------
// ISR is unique so can't be in .h
//-----------------------------------------------------------------------------
SI_INTERRUPT(Timer0_ISR, TIMER0_IRQn) {
  TCON_TR0 = 0;   // Stop Timer0
  timer0_done = true;
}

