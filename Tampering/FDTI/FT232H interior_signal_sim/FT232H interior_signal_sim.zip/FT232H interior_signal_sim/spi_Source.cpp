﻿#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "ftd2xx.h"
#include <string.h>  

// ==================== FTDI Definitions ====================

// for i2c like protocol, connect d1,d2 to send ack properly
const BYTE MSB_BYTE_IN_POSITIVE_TRIGG = 0x24; //  x24
const BYTE MSB_BIT_IN_POSITIVE_TRIGG = 0x26;  //  x26
const BYTE MSB_BYTE_OUT_POSITIVE_TRIGG = 0x11;  // x11
const BYTE MSB_BIT_OUT_POSITIVE_TRIGG = 0x13; // x13


// Ideally, SCL frequency = 60 / ((1 + value) * 2) MHz , but i2c/spi is different
DWORD dwClockDivisor = 0x0128;  // ~100kHz   


FT_STATUS ftStatus;        // Status returned by D2XX API to indicate result
FT_HANDLE ftHandle;        // Handle for FTDI device port

DWORD dwNumBytesToSend = 0;         // Number of bytes to send
DWORD dwNumBytesSent = 0;
DWORD dwNumBytesRead = 0;
DWORD dwNumInputBuffer = 0;

#define OUT_MAX_BYTES 4096  // FDTI MAX SIZE
#define IN_MAX_BYTES 30
BYTE OutputBuffer[OUT_MAX_BYTES];   // Buffer for MPSSE commands and data to be sent (FIFO TX)
BYTE InputBuffer[IN_MAX_BYTES];     // Buffer for data read from FTDI


BYTE InputData[OUT_MAX_BYTES];  // buffer to store all bytes
int input_len[1024];    // sequence length buffer
int len_count = 0;      // 

int DelayTimes[] = {
    6778, 420, 5264, 190, 4706, 306, 5220, 230, 5688, 424, 4526, 729, 7061, 1155, 6613, 1091, 7299, 535, 6748, 1230, 4581, 5079, 4767, 5756, 4526, 214, 0
};  // delay time buffer, remember to pad 0  at last to fit len_idx


BYTE FixData[OUT_MAX_BYTES];
int fix_data_len[1024];
int fix_len_count = 0;
int fix_DelayTimes[] = {
    9053, 400, 6555, 400, 6655, 562, 6256, 540, 6355, 557, 6255, 540, 6255, 557, 6355, 545, 6256, 410, 6655, 390, 2002, 134, 2626, 0
};



int Data_idx = 0;   // ?g?J data ????m 


// ==================== Other Definitions ====================
LARGE_INTEGER frequency;  // High-res counter frequency (used for windowa timing)
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))  // arr element number

// input files' variables
#define MAX_FILES 100
#define MAX_PATH_LEN 256

int file_count = 0;
char file_list[MAX_FILES][MAX_PATH_LEN];

const char* on_off_folder_path = "..\\..\\fix_data";    // on off power signal sequence
const char* input_folder_path = "..\\..\\input_data";   // Relative path to .exe (\\..\\ = go up one folder)



// ==================== Setup ====================
void InitWinCounter(void)
{
    // Get frequency
    if (!QueryPerformanceFrequency(&frequency)) {
        printf("Windows counter not supported.\n");
        exit(EXIT_FAILURE);

    }
}

void InitFTDI(void)
{
    //Try to open the FT2232H device port and get the valid handle for subsequent access 
    char SerialNumBuf[64];
    ftStatus = FT_ListDevices((PVOID)0, &SerialNumBuf, FT_LIST_BY_INDEX | FT_OPEN_BY_SERIAL_NUMBER);  // Change device index = (PVOID)0 if not connected
    ftStatus = FT_OpenEx((PVOID)SerialNumBuf, FT_OPEN_BY_SERIAL_NUMBER, &ftHandle);

    if (ftStatus == FT_OK)
    {
        ftStatus |= FT_ResetDevice(ftHandle);           //Reset USB device  
        ftStatus |= FT_SetBitMode(ftHandle, 0x0, 0x00); //Reset controller 
        ftStatus |= FT_SetBitMode(ftHandle, 0x0, 0x02); //Enable MPSSE mode
        if (ftStatus != FT_OK) {
            printf("Failed to init device\n");
            exit(1);
        }
        Sleep(50); // Wait for all the USB stuff to complete and work

        FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX); //Clear buffers

        OutputBuffer[dwNumBytesToSend++] = '\x8A'; // Ensure disable clock divide by 5 for 60Mhz master clock
        OutputBuffer[dwNumBytesToSend++] = '\x97'; // Ensure turn off adaptive clocking(JTAG)
        //OutputBuffer[dwNumBytesToSend++] = '\x8C'; // 3 phase data clock (= control data, clk separately, for i2c)

        OutputBuffer[dwNumBytesToSend++] = 0x9E; // Enable drive-zero mode = open-drain (set d1 high=release for I2C) ...( FT232H only)
        OutputBuffer[dwNumBytesToSend++] = 0x07; // ... on the bits AD0, 1 and 2 of the lower port...
        OutputBuffer[dwNumBytesToSend++] = 0x00; // ...not required on the upper port AC 0-7

        ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
        dwNumBytesToSend = 0; //Clear output buffer

        // SK frequency = 60MHz /((1 + [(1 +0xValueH*256) OR 0xValueL])*2)
        // Don't rely on this formula if in high speed!!!
        OutputBuffer[dwNumBytesToSend++] = '\x86'; //Command to set clock divisor
        OutputBuffer[dwNumBytesToSend++] = dwClockDivisor & '\xFF'; //Set 0xValueL of clock divisor
        OutputBuffer[dwNumBytesToSend++] = (dwClockDivisor >> 8) & '\xFF'; //Set 0xValueH of clock divisor
        ftStatus = FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
        dwNumBytesToSend = 0;

        OutputBuffer[dwNumBytesToSend++] = '\x80'; // Command to set directions of lower 8 pins and force value on bits set as output
        OutputBuffer[dwNumBytesToSend++] = '\x00'; // Set data, clk low
        OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set as outputs with bit '1', others as input with bit ??0??

        FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
        dwNumBytesToSend = 0;

        Sleep(20); //Delay 20ms 

        OutputBuffer[dwNumBytesToSend++] = '\x88'; // mpsse wait until GPIOL1=D5 or D0 is high(non-mpsse operation will continue) 
        FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
        dwNumBytesToSend = 0;
    }
}

void CleanupFTDI()
{
    FT_STATUS ftStatus = FT_Close(ftHandle);  // FT2232H
    if (ftStatus != FT_OK) {
        printf("Failed to close FT232H device\n");
        exit(1);
    }
}


// ==================== Timing  ==================== 

// wait high, ?`?N10ms?U??delay??????
void precise_delay(int total_us)
{
    if (total_us < 10000) {
        int rounds = total_us / 200;
        int remain = (total_us % 200) * 986 / 200;

        for (int i = 0; i < remain; i++) {
            OutputBuffer[dwNumBytesToSend++] = '\x80';
            OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set D1,D0 high (commu stop)
            OutputBuffer[dwNumBytesToSend++] = '\x03';
        }
        FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
        dwNumBytesToSend = 0;

        for (int i = 0; i < rounds; i++)
        {
            for (int j = 0; j < 986; j++) {
                OutputBuffer[dwNumBytesToSend++] = '\x80';
                OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set D1,D0 high (commu stop)
                OutputBuffer[dwNumBytesToSend++] = '\x03';
            }

            FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);  // prevent overflow
            dwNumBytesToSend = 0;
        }
    }

    else {
        LARGE_INTEGER start, current;

        QueryPerformanceCounter(&start);  // Windows api

        // ?? counter ticks
        LONGLONG wait_ticks = (frequency.QuadPart * total_us) / 1000000;

        do {
            QueryPerformanceCounter(&current);
        } while ((current.QuadPart - start.QuadPart) < wait_ticks);
    }
}


// ==================== Core Functions ==================== 

// send bytes(override ack) with no last ack bit, for x41
BOOL _send_no_last_ack(unsigned char* data_list, DWORD data_len)
{
    for (DWORD i = 0; (i + 1) < data_len; i++)  // beware unsigned bool comparison 
    {
        OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_OUT_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = data_list[i];  // 1 byte 

        /*
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02';  //release d1(for bit read)
        OutputBuffer[dwNumBytesToSend++] = '\x03';

        // read ack
        OutputBuffer[dwNumBytesToSend++] = MSB_BIT_IN_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        */

        // override ack bit 
        OutputBuffer[dwNumBytesToSend++] = MSB_BIT_OUT_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
    }

    // last byte 
    OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_OUT_POSITIVE_TRIGG;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = data_list[data_len - 1];


    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    return TRUE;
}


// read bytes without last ack bit, for x41
BOOL _read_no_last_ack(DWORD data_len)
{
    for (DWORD i = 0; (i + 1) < data_len; i++)  // beware unsigned bool comparison 
    {
        OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_IN_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;

        // ack bit
        OutputBuffer[dwNumBytesToSend++] = MSB_BIT_OUT_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
    }

    // last byte 
    OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_IN_POSITIVE_TRIGG;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = 0x0;


    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    return TRUE;
}


// send and read ack,  for x41
BOOL _test_no_last_ack(unsigned char* data_list, DWORD data_len)
{
    for (DWORD i = 0; (i + 1) < data_len; i++)  // beware unsigned bool comparison 
    {
        OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_OUT_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = data_list[i];  // 1 byte 

        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02';  //release d1 to read ack bit properly
        OutputBuffer[dwNumBytesToSend++] = '\x03';

        // read ack
        OutputBuffer[dwNumBytesToSend++] = MSB_BIT_IN_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
    }

    // last byte 
    OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_OUT_POSITIVE_TRIGG;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = data_list[data_len - 1];


    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    return TRUE;
}


// mimic x41 first 4 bytes w/r
BOOL _x41_first_4(unsigned char* data_list) {
    OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_OUT_POSITIVE_TRIGG;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = data_list[0];

    // override ack bit 
    OutputBuffer[dwNumBytesToSend++] = MSB_BIT_OUT_POSITIVE_TRIGG;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = 0x0;

    // read 2
    for (int i = 0; i < 2; i++) {
        OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_IN_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;

        // ack bit
        OutputBuffer[dwNumBytesToSend++] = MSB_BIT_OUT_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
    }

    // write 1 
    OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_OUT_POSITIVE_TRIGG;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = data_list[3];

    // read 1
    //OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_IN_POSITIVE_TRIGG;
    //OutputBuffer[dwNumBytesToSend++] = 0x0;
    ///OutputBuffer[dwNumBytesToSend++] = 0x0;

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    return true;
}



// ==================== Sequence Functions ==================== 

// send and read ack/nack, x40
BOOL Send_x40(unsigned char* data_list, DWORD data_len) {
    // start condition
    for (int i = 0; i < 20; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x01';
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    for (int i = 0; i < 10; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x00';  // all low
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    for (DWORD i = 0; i < data_len; i++)
    {
        OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_OUT_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = data_list[i];  // 1 byte   

        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02';  //release d1 to read ack bit properly
        OutputBuffer[dwNumBytesToSend++] = '\x03';

        // read ack
        OutputBuffer[dwNumBytesToSend++] = MSB_BIT_IN_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
    }

    // wait
    for (int i = 0; i < 75; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02'; // Set D0 low , D1 high 
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    // stop condition
    for (int i = 0; i < 20; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x00'; // Set all low
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    for (int i = 0; i < 51; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x01'; // Set d0 high
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set D1,D0 high (commu stop)
    OutputBuffer[dwNumBytesToSend++] = '\x03';


    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    return true;
}


// x40, send some bytes and read with ack
BOOL Read_138(unsigned char* data_list, DWORD data_len)
{
    // start condition
    for (int i = 0; i < 20; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x01';
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    for (int i = 0; i < 10; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x00';
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    // write 
    for (DWORD i = 0; i < data_len; i++) {
        OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_OUT_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = data_list[i];  // 1 byte  

        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02';  //release d1
        OutputBuffer[dwNumBytesToSend++] = '\x03';

        // read ack
        OutputBuffer[dwNumBytesToSend++] = MSB_BIT_IN_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
    }

    // read pass
    for (DWORD i = 0; i < 0; i++)
    {
        OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_IN_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;  // 1 byte  

        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02';  //release d1 to read ack bit properly
        OutputBuffer[dwNumBytesToSend++] = '\x03';

        // simpified ack bit
        OutputBuffer[dwNumBytesToSend++] = MSB_BIT_OUT_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
    }

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    // wait
    for (int i = 0; i < 75; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02'; // Set D0 low , D1 high 
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    // stop condition
    for (int i = 0; i < 20; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x00'; // Set all low
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    for (int i = 0; i < 54; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x01'; // Set d0 high
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set D1,D0 high (commu stop)
    OutputBuffer[dwNumBytesToSend++] = '\x03';


    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    return TRUE;
}



// x40, send some bytes and read with ack
BOOL test_x40(unsigned char* data_list, DWORD data_len)
{
    // start condition
    for (int i = 0; i < 20; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x01';
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    for (int i = 0; i < 10; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x00';
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    // write 1
    for (DWORD i = 0; i < 2; i++) {
        OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_OUT_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = data_list[i];  // 1 byte  

        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02';  //release d1
        OutputBuffer[dwNumBytesToSend++] = '\x03';

        // read ack
        OutputBuffer[dwNumBytesToSend++] = MSB_BIT_IN_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
    }

    // read
    for (DWORD i = 0; i < (data_len - 2); i++)
    {
        OutputBuffer[dwNumBytesToSend++] = MSB_BYTE_IN_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;  // 1 byte  

        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02';  //release d1 to read ack bit properly
        OutputBuffer[dwNumBytesToSend++] = '\x03';

        // simpified ack bit
        OutputBuffer[dwNumBytesToSend++] = MSB_BIT_OUT_POSITIVE_TRIGG;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
        OutputBuffer[dwNumBytesToSend++] = 0x0;
    }

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    // wait
    for (int i = 0; i < 75; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02'; // Set D0 low , D1 high 
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    // stop condition
    for (int i = 0; i < 20; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x00'; // Set all low
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    for (int i = 0; i < 50; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x01'; // Set d0 high
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set D1,D0 high (commu stop)
    OutputBuffer[dwNumBytesToSend++] = '\x03';


    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    return TRUE;
}





// made by  _send_no_last_ack
BOOL Send_x41(unsigned char* data_list, DWORD data_len)
{
    unsigned char* response = &data_list[4];  // reponse start addr
    DWORD len = data_len - 4;

    // start condition
    for (int i = 0; i < 20; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x01';
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    for (int i = 0; i < 10; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x00';
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    //_send_no_last_ack(data_list, 4);
    //_test_no_last_ack(data_list, 4);  // see ack nack
    _x41_first_4(data_list);

    // wait
    for (int i = 0; i < 190; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02'; // Set D1 high  
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    // concate bit and byte operation often encounter clk not idle problem 
    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    // simpified ack bit
    OutputBuffer[dwNumBytesToSend++] = MSB_BIT_OUT_POSITIVE_TRIGG;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = 0x0;

    _send_no_last_ack(response, len);

    // wait 
    for (int i = 0; i < 95; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02'; // Set D1 high 
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    // simpified, ignore Nack bit
    OutputBuffer[dwNumBytesToSend++] = MSB_BIT_OUT_POSITIVE_TRIGG;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = 0x80;  // at front

    // stop
    for (int i = 0; i < 20; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x00'; // Set all low
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }
    for (int i = 0; i < 57; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x01'; // Set d0 high
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set D1,D0 high (commu stop)
    OutputBuffer[dwNumBytesToSend++] = '\x03';

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    return TRUE;
}


// send 4  and read 
BOOL test_x41(unsigned char* data_list, DWORD data_len)
{
    unsigned char* response = data_list + 4;  // reponse start addr
    DWORD length = data_len - 4;
    unsigned char* temp = response + 8;


    // start condition
    for (int i = 0; i < 20; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x01';
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }
    for (int i = 0; i < 10; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x00';
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    // send
    //_send_no_last_ack(data_list, 4);    
    _x41_first_4(data_list);

    // wait
    for (int i = 0; i < 190; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02'; // release d1
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    //  ack bit
    OutputBuffer[dwNumBytesToSend++] = MSB_BIT_OUT_POSITIVE_TRIGG;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = 0x0;

    // send and read ack 
    //_test_no_last_ack(response, length);

    // read and ack
    _read_no_last_ack(length);


    // wait 
    for (int i = 0; i < 95; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x02'; // Set D1 high 
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    // simpified, ignore Nack bit
    OutputBuffer[dwNumBytesToSend++] = MSB_BIT_OUT_POSITIVE_TRIGG;
    OutputBuffer[dwNumBytesToSend++] = 0x0;
    OutputBuffer[dwNumBytesToSend++] = 0x80;  // at front

    // construct wave form 
    for (int i = 0; i < 20; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x00'; // Set all low
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }
    for (int i = 0; i < 57; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x01'; // Set d0 high
        OutputBuffer[dwNumBytesToSend++] = '\x03';
    }

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set D1,D0 high (commu stop)
    OutputBuffer[dwNumBytesToSend++] = '\x03';

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    return TRUE;
}



// ==================== Read file ==================== 

// Count CSV files and store their paths in file_list 
void ScanCsvFiles(const char* folder_path) {
    file_count = 0;
    Data_idx = 0;   // reset for new file
    char search_path[MAX_PATH_LEN]; // max char size
    snprintf(search_path, MAX_PATH_LEN, "%s\\*.csv", folder_path);  //  search_path = folder_path + \\*.csv

    WIN32_FIND_DATAA fd;
    HANDLE hFind = FindFirstFileA(search_path, &fd);

    if (hFind == INVALID_HANDLE_VALUE) {
        printf("No .csv files found.\n");
        return;
    }

    // record file path
    do {
        snprintf(file_list[file_count], MAX_PATH_LEN, "%s\\%s", folder_path, fd.cFileName);
        file_count++;
    } while (FindNextFileA(hFind, &fd));

    FindClose(hFind);
}


// Read one .csv to input_file and input_len
void ReadCsvFile(char* file_path, unsigned char* data_list, int* len_list, int* len_count)
{
    FILE* fp;
    errno_t err = fopen_s(&fp, file_path, "r");
    if (err != 0 || !fp) {
        printf("Failed to open file: %s\n", file_path);
        return;
    }

    printf("Processing file: %s\n", file_path);

    char line[256]; // to store current column
    char* endptr;

    int current_len = 0;

    fgets(line, sizeof(line), fp);  // ignore header

    while (fgets(line, sizeof(line), fp)) {
        char* p = line;
        int comma = 0;

        // ???3??
        while (*p && comma < 2) {
            if (*p == ',') comma++;
            p++;
        }

        if (!*p) continue;

        char* start = p;

        while (*p && *p != ',' && *p != '\n') p++;

        if (*p == ',' || *p == '\n') {
            *p = '\0';  // ?I?_
        }


        // ===== ?P?_ stop str =====
        if (strcmp(start, "Stop") == 0) {
            len_list[*len_count] = current_len;
            current_len = 0;
            (*len_count)++;
            continue;
        }

        // ===== HEX ?? =====
        unsigned long value = strtoul(start, &endptr, 16);  // str to int

        if (endptr != start) {
            data_list[Data_idx++] = (BYTE)value;
            current_len++;
        }
        else {
            printf("Invalid HEX: %s\n", start);
        }
    }

    if (current_len != 0) {
        len_list[*len_count] = current_len;  // ??????W
        current_len = 0;
        (*len_count)++;
    }

    fclose(fp);
}



// ==================== fix sequences ==================== 

// fix seq in PowerOn/PowerOff stage, can only be used after read .csv
void _on_off_seq(void) {
    bool is_send = true;
    int offset = 0;

    for (int i = 0; i < fix_len_count; i++) {
        unsigned int len = fix_data_len[i];

        if (is_send) {
            Send_x40(&FixData[offset], len);
        }
        else {
            Send_x41(&FixData[offset], len);
        }

        precise_delay(fix_DelayTimes[i]);
        offset += len;
        is_send ^= 1;
    }
}

// no need(send by cpu)
void PowerOn(void) {

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x00'; // Set all low
    OutputBuffer[dwNumBytesToSend++] = '\x03';

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    Sleep(1000);

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set all high
    OutputBuffer[dwNumBytesToSend++] = '\x03';

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x00'; // Set all low
    OutputBuffer[dwNumBytesToSend++] = '\x03';

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    precise_delay(220000);  //  139
    //precise_delay(5000);    // 217

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set all high
    OutputBuffer[dwNumBytesToSend++] = '\x03';


    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    precise_delay(146000);


    _on_off_seq();
}


void PowerOff(void) {
    _on_off_seq();

    Sleep(733);

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x00'; // Set all low
    OutputBuffer[dwNumBytesToSend++] = '\x03';

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    precise_delay(38000);

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x03'; // Set all high
    OutputBuffer[dwNumBytesToSend++] = '\x03';

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;

    precise_delay(153000);

    _on_off_seq();
    /*
    precise_delay(2000000);

    OutputBuffer[dwNumBytesToSend++] = '\x80';
    OutputBuffer[dwNumBytesToSend++] = '\x00'; // power off
    OutputBuffer[dwNumBytesToSend++] = '\x03';

    FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
    dwNumBytesToSend = 0;
    */
}


// ====================  Data w,r process ==================== 

// w/r data, can only be used after read .csv
void MainCommu(void) {
    bool is_send = true;
    int offset = 0;  // offset addr of data
    unsigned int len = 0;

    for (int i = 0; i < len_count; i++) {
        len = input_len[i];

        if (is_send) {
            Send_x40(&InputData[offset], len);
            /*
            if (i == (len_count - 1)) {
                Read_138(&input_data[offset], len);   // resp
            }
            else {
                Send_x40(&input_data[offset], len);
            }
            */
        }
        else {
            //Send_x41(&input_data[offset], len);

            if (i == (len_count - 2)) {
                test_x41(&InputData[offset], len);
            }
            else {
                Send_x41(&InputData[offset], len);
            }
        }

        precise_delay(DelayTimes[i]);
        offset += len;
        is_send ^= 1;  // intertwined
    }
}


// Main routine
void CommFlow(const char* fix_folder_path, const char* input_folder_path) {
    // read data
    ScanCsvFiles(fix_folder_path);

    for (int i = 0; i < file_count; i++) {
        ReadCsvFile(file_list[i], FixData, fix_data_len, &fix_len_count);
    }

    ScanCsvFiles(input_folder_path);

    for (int i = 0; i < file_count; i++) {
        ReadCsvFile(file_list[i], InputData, input_len, &len_count);
    }

    if (len_count > ARRAY_SIZE(DelayTimes)) {
        printf("%d\n", len_count);
        printf("size of data is not match with delay time\n");
        return;
    }

    if (fix_len_count != ARRAY_SIZE(fix_DelayTimes)) {
        printf("%d\n", fix_len_count);
        printf("size of fix data is not match with fix_delay_times\n");
        return;
    }

    // start
    //PowerOn();
    //Sleep(1000);

    //printf("%02X\n ", *InputData);

    MainCommu();

    Sleep(1000);
    PowerOff();
}


// ==================== Demo/Main routine ==================== 
void Demo(void)
{
    /*
    BYTE BytesToBeSend[5] = {0x40, 0x05, 0x0, 0x00, 0x5};

    PowerOn();

    Send_x40(BytesToBeSend, sizeof(BytesToBeSend));
    precise_delay(1500);
    Send_x41(BytesToBeSend, sizeof(BytesToBeSend));
    */

    ScanCsvFiles("..\\..\\fix_data");

    for (int i = 0; i < file_count; i++) {
        ReadCsvFile(file_list[i], FixData, fix_data_len, &fix_len_count);
    }

    ScanCsvFiles("..\\..\\input_data");

    for (int i = 0; i < file_count; i++) {
        ReadCsvFile(file_list[i], InputData, input_len, &len_count);
    }


    for (int i = 0; i < 100; i++) {
        OutputBuffer[dwNumBytesToSend++] = '\x80';
        OutputBuffer[dwNumBytesToSend++] = '\x03';
        OutputBuffer[dwNumBytesToSend++] = '\x03';

        FT_Write(ftHandle, OutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
        dwNumBytesToSend = 0;
    }
    // wait 1.5s for data commu.
    precise_delay(1400000);


    int len = 0;

    bool is_send = true;
    int offset = 0;  // offset addr of data
    //offset = 814;    // for data sending only

    // i=20 for data sending
    for (int i = 0; i < len_count; i++) {
        unsigned int len = input_len[i];

        if (is_send) {
            //Send_x40(&InputData[offset], len);
            test_x40(&InputData[offset], len);
        }
        else {
            //Send_x41(&InputData[offset], len);
            test_x41(&InputData[offset], len);
        }

        precise_delay(DelayTimes[i]);
        offset += len;
        is_send ^= 1;  // intertwined
    }

    Sleep(1000);
    PowerOff();
    Sleep(50); //Delay for a while to ensure EEPROM program is completed
}


// ==================== Main ==================== 
int main()
{
    InitWinCounter();
    InitFTDI();

    //CommFlow(on_off_folder_path, input_folder_path);
    Demo();

    CleanupFTDI();

    printf("Program finished. Press Enter to exit...\n");
    getchar();  // ????Τ?? Enter ?? 
    return 0;
}



 
